(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"The Learn Phase2_atlas_1", frames: [[819,154,272,197],[1093,154,272,197],[1097,552,200,200],[819,353,272,197],[1093,353,272,197],[549,552,272,197],[823,552,272,197],[272,154,275,407],[1733,0,270,600],[2005,0,21,29],[2028,0,18,21],[1299,552,119,262],[1444,0,287,633],[2028,23,17,21],[549,358,206,9],[0,0,1442,152],[549,154,268,202],[0,154,270,541]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.currentSoundStreamInMovieclip;
	this.soundStreamDuration = new Map();
	this.streamSoundSymbolsList = [];

	this.gotoAndPlayForStreamSoundSync = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.gotoAndPlay = function(positionOrLabel){
		this.clearAllSoundStreams();
		var pos = this.timeline.resolve(positionOrLabel);
		if (pos != null) { this.startStreamSoundsForTargetedFrame(pos); }
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(this.currentFrame);
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
		this.clearAllSoundStreams();
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
		this.clearAllSoundStreams();
	}
	this.startStreamSoundsForTargetedFrame = function(targetFrame){
		for(var index=0; index<this.streamSoundSymbolsList.length; index++){
			if(index <= targetFrame && this.streamSoundSymbolsList[index] != undefined){
				for(var i=0; i<this.streamSoundSymbolsList[index].length; i++){
					var sound = this.streamSoundSymbolsList[index][i];
					if(sound.endFrame > targetFrame){
						var targetPosition = Math.abs((((targetFrame - sound.startFrame)/lib.properties.fps) * 1000));
						var instance = playSound(sound.id);
						var remainingLoop = 0;
						if(sound.offset){
							targetPosition = targetPosition + sound.offset;
						}
						else if(sound.loop > 1){
							var loop = targetPosition /instance.duration;
							remainingLoop = Math.floor(sound.loop - loop);
							if(targetPosition == 0){ remainingLoop -= 1; }
							targetPosition = targetPosition % instance.duration;
						}
						instance.loop = remainingLoop;
						instance.position = Math.round(targetPosition);
						this.InsertIntoSoundStreamData(instance, sound.startFrame, sound.endFrame, sound.loop , sound.offset);
					}
				}
			}
		}
	}
	this.InsertIntoSoundStreamData = function(soundInstance, startIndex, endIndex, loopValue, offsetValue){ 
 		this.soundStreamDuration.set({instance:soundInstance}, {start: startIndex, end:endIndex, loop:loopValue, offset:offsetValue});
	}
	this.clearAllSoundStreams = function(){
		this.soundStreamDuration.forEach(function(value,key){
			key.instance.stop();
		});
 		this.soundStreamDuration.clear();
		this.currentSoundStreamInMovieclip = undefined;
	}
	this.stopSoundStreams = function(currentFrame){
		if(this.soundStreamDuration.size > 0){
			var _this = this;
			this.soundStreamDuration.forEach(function(value,key,arr){
				if((value.end) == currentFrame){
					key.instance.stop();
					if(_this.currentSoundStreamInMovieclip == key) { _this.currentSoundStreamInMovieclip = undefined; }
					arr.delete(key);
				}
			});
		}
	}

	this.computeCurrentSoundStreamInstance = function(currentFrame){
		if(this.currentSoundStreamInMovieclip == undefined){
			var _this = this;
			if(this.soundStreamDuration.size > 0){
				var maxDuration = 0;
				this.soundStreamDuration.forEach(function(value,key){
					if(value.end > maxDuration){
						maxDuration = value.end;
						_this.currentSoundStreamInMovieclip = key;
					}
				});
			}
		}
	}
	this.getDesiredFrame = function(currentFrame, calculatedDesiredFrame){
		for(var frameIndex in this.actionFrames){
			if((frameIndex > currentFrame) && (frameIndex < calculatedDesiredFrame)){
				return frameIndex;
			}
		}
		return calculatedDesiredFrame;
	}

	this.syncStreamSounds = function(){
		this.stopSoundStreams(this.currentFrame);
		this.computeCurrentSoundStreamInstance(this.currentFrame);
		if(this.currentSoundStreamInMovieclip != undefined){
			var soundInstance = this.currentSoundStreamInMovieclip.instance;
			if(soundInstance.position != 0){
				var soundValue = this.soundStreamDuration.get(this.currentSoundStreamInMovieclip);
				var soundPosition = (soundValue.offset?(soundInstance.position - soundValue.offset): soundInstance.position);
				var calculatedDesiredFrame = (soundValue.start)+((soundPosition/1000) * lib.properties.fps);
				if(soundValue.loop > 1){
					calculatedDesiredFrame +=(((((soundValue.loop - soundInstance.loop -1)*soundInstance.duration)) / 1000) * lib.properties.fps);
				}
				calculatedDesiredFrame = Math.floor(calculatedDesiredFrame);
				var deltaFrame = calculatedDesiredFrame - this.currentFrame;
				if((deltaFrame >= 0) && this.ignorePause){
					cjs.MovieClip.prototype.play.call(this);
					this.ignorePause = false;
				}
				else if(deltaFrame >= 2){
					this.gotoAndPlayForStreamSoundSync(this.getDesiredFrame(this.currentFrame,calculatedDesiredFrame));
				}
				else if(deltaFrame <= -2){
					cjs.MovieClip.prototype.stop.call(this);
					this.ignorePause = true;
				}
			}
		}
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._1 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3mentalkingphone = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._6 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.MainscreenshotwithHoleforimages_Small = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Microphone = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.pausebutton = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.PhaseDropdown = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.PhoneFrame2_633x287 = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.PlayButton = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.slidingball_small = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.StoryPagesTogetherLtoR = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Titlepageimage = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.TranslateRevisePhase = function() {
	this.initialize(ss["The Learn Phase2_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Tween25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Titlepageimage();
	this.instance.setTransform(-135,-101.75,1.0075,1.0074);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-101.7,270,203.5);


(lib.Tween24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Titlepageimage();
	this.instance.setTransform(-135,-101.75,1.0075,1.0074);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-101.7,270,203.5);


(lib.Tween23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.MainscreenshotwithHoleforimages_Small();
	this.instance.setTransform(-135,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-300,270,600);


(lib.Tween22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.MainscreenshotwithHoleforimages_Small();
	this.instance.setTransform(-135,-300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-300,270,600);


(lib.Tween20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PhoneFrame2_633x287();
	this.instance.setTransform(-143,-310.2,1,0.9785);

	this.instance_1 = new lib.PhoneFrame2_633x287();
	this.instance_1.setTransform(-144,-309.2,1,0.9785);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144,-310.2,288,620.4);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._3mentalkingphone();
	this.instance.setTransform(-100,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-100,-100,200,200);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.StoryPagesTogetherLtoR();
	this.instance.setTransform(-721,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-721,-76,1442,152);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.StoryPagesTogetherLtoR();
	this.instance.setTransform(-721,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-721,-76,1442,152);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.slidingball_small();
	this.instance.setTransform(-103,-4.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103,-4.5,206,9);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.slidingball_small();
	this.instance.setTransform(-103,-4.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103,-4.5,206,9);


(lib.Touch = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("ACNEuIgJgBIgJgBIgJgBIgJgCIgJgBIgIgDIgHgEIgIgDIgIgDIgIgEIgHgDIgHgEIgHgEIgGgFIgGgFIgGgFIgGgFIgFgGIgFgFIgEgGIgFgHQgYgJgWgLQgcgPgbgSQgcgRgagSQgXgPgVgRQgWgRgUgSQg1ghgZg4QgYg2AIg7QAJg9ArgtQAwgyBFgLQBBgKA5AgQAnAVAXAlIAFAEIAFAFIAFAEIAFAFIAFAEIAPAKIAPAJIAPAKIAWANIAWAOIAPAJQAuAOApAZQApAYAdAlQAYAeAMAjQAMAlAAAnQAAAxgXAsQgOAZgUAUIgIAGIgIAGIgIAGIgHAGIgIAGIgQAIIgQAHIgQAFIgQAEIgRACIgSABIgJgBg");
	this.shape.setTransform(71.02,31.1225,1,1,-14.9992);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AEHSfQgRgGgQgKQgWgNgSgSQgRgPgNgTQgOgVgKgXQgJgUgJgWQgKgZgGgaQgDgNgEgMIgOggIgLgYIgJgZIgIgZIgGgZIgCgIQgig8AJhEQAIg+AsgtQAtguA/gKQBJgMA+AmQBOAxAUBYQAKAoANAoIAOAgIALAZQAFAMAEANIAIAYIAHAZQAeApAGAyQAGAugPAqQgRAvglAiQglAggwANQgXAGgXAAQggAAgggMgApcOJIgJgBIgIgCIgJgBIgJgBIgIgBIgJgBQgigJgcgVQghgYgVgjQgUgjgGgoQgFgoAMgnQALgmAZgeIAQgRQBChVBNhMQA9g7BJgpQAlgVArgEQBYgHBCA6QBJA/gIBgQgIBkhVA1QgSALgUAHIgGAFIgGAGIgGAFIgHAFIgHAGIgGAFIgHAFIgLAMIgLAMIgKANIgRAUIgSATIgMAMIgWAhQgMAPgPANQgOAMgQAKQgPALgRAGQgQAGgQAEQgUAFgWAAIgBAAgAryAtQg+gBgzgkQgxgigVg5QgVg4APg6QAQg8AwgpQAtgmA6gHIAVgBIARgEIASgDIASgCIASgBIAPAAIAGAAQCCgRCEAKQBqAJAyBeQAzBgg4BdQgrBGhRARQgvAJgxgBIhpgCIgLACIgSAEIgSACIgSABIgQABIgGABIgQADIgQACIgPACIgOABIgQABIgKABIgFAAgAH1iHQgzgEgqgcQgngagXgoQgagtAAgzIAAgWQAAgMACgNIAFgZIAIgYQAEgMAFgMIAEgHIAIgXIAHgOIAGgNIAHgPIAJgPIAJgNIALgMIACgEIADgGIAEgFIAEgFIAKgXIALgYQAGgMAHgLIAIgLIAMgUQAGgKAHgJIACgEIAEgHIAFgHIAFgHIAGgHIAIgQIAIgPIAGgOIAGgMIAHgMIAKgPIAGgHQAXg5AtgqQAvgtBCgFQBCgFA4AkQA6AlAVBBQAYBNgiBIQgJATgMARIgHAOIgEAGIgEAHIgEAHIgFAIIgFAHIgGAIIgMAYIgIAQIgIARIgIAOIgIANIgJAMIgCAEIgEAHIgFAHIgFAHIgFAGIgBADIgEAFIgDAEIgFAHIgDAFIgDAFIgFAQIgFAPIgHAOIgJAOIgDAGIgFAFIgEAGIgEAGIgEAHIgEAGIgEAFIgFAGIgDAHIgDAIIgCAIIgEAIIgDAHQgIAwgeAnQgeAmgrAVQgmASgpAAIgQgBgAholiQgqgJgigZIgHgFIgGgGIgGgGIgGgGIgGgGIgGgGIgGgGQgJgMgIgOQgJgRgFgSQgGgTgDgUQgEgTABgVIABgpIABgSQgCgDgBgEIgDgIIgDgIIgCgJIgCgIIgDgIIgCgJIgIgQIgIgOIgJgQIgJgOQgEgHgCgIIgEgGIgDgHIgEgGIgEgHIgEgGIgDgIIgDgHIgEgQIgDgQIgEgIIgDgIIgDgJIgEgIIgCgDIgFgJIgFgJIgFgIIgFgJIgGgIIgFgPIgEgPIgDgPIgCgPIgBgPIABgQIABgIQAIhCAtgxQAogrA4gNQA0gNA0AQQA2ARAlAtQAgAqAYAwQAJASABAUIAEAJIADAJIADAIIAEAJIACAJIAEAHIADAGIADAHIADAHIACAHIABACIAAgBIABACIACAEIALAQIAMAVIALAUIAJAXIAJAZIAGAZIAKAVQAGANAEAOIAIAhQAEAQABAQQACARgCARIgEAdIAAAHQAMArgIArQgIAsgaAlQgWAdgfAUQgeAUgjAHQgUAEgVAAQgTAAgTgEg");
	this.shape_1.setTransform(-10.4745,0.2633);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.4,-119.2,213.2,239);


(lib.handbrown = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkdehQlyhqjRkiQk4mviWnGQhAjCAYilQAci+B0hpQCMh/ECjVQAWgSAKgSQAKgTAAgbQgCpmABq9QAAh1BEhSQBDhQBygaQCLghB2BlQB0BjgCCKQgCB+ABC4IABE2IAAD6QBPgwBPgLQBLgKBRAWQBTAXAsBCQAlA4APBgQCVhUCQAqQCfAtA3CMIAQgBQCfhtCVA8QCVA7AoC+QAUBgABBhIACH4QABEdgEDcQgEDng3C7Qg+DSiDCmQjrEtmdAnQhjAKhjAAQkaAAkThQgAshjDQgIADgDADIivCaQhlBYhGBDQhDA/gYCAQgaCOA2CoQCLGxE1GwQCsDyEvBkQF/B+GVgxQHTg6DBm5QBljoADjzQAHoPgIoyQgBhfgxh5QgnhhiGAEQhgAEgsBkQgZA3gCAeQgEA6gHC6QgBApgPATQgOATgegCQgigCgNgXQgJgRAAgjQABiygBixQAAhnhHg7QhHg7hnARQieAagBCiIAAF8QAABFg7gBQg4gBAAhCIAAiqQAAkbgBiOQgBhDgYgrQgYgpgtgPQh3glhPA6QhQA6gBB8IgDH5IAAApQgBAYgHANQgHAOgRAMQgSANgPAAQgLAAgPgPQgNgNgJgQQgEgIAAgRIACgdIAA1fIAAiJQABhSgCg4QgDhshOg7QhOg7hjAdQiGAnAAClMAAAAjiIABAcQAAAQgDALQgGAYgQANQgRAOgXgIQgNgEgOgQQgIgJgPgWQgEgFABgNIACgVIAAsPIgSAHg");
	this.shape.setTransform(0.024,0.0047);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#946038").s().p("AkpciQkvhkitjxQk1mxiLmxQg1inAaiPQAXh/BDhAQBGhCBmhZICuiZQAEgDAHgDIASgIIAAMQIgBAVQgBAMAEAGQAOAVAIAJQAOAQAOAFQAWAHASgOQAPgMAGgZQADgKAAgRIAAgbMAAAgjjQAAikCFgnQBkgeBOA7QBNA8AEBsQABA3AABSIgBCKIAAVfIgBAcQgBARAFAJQAJAPANANQAPAQALAAQAPgBARgMQASgMAHgOQAHgOABgXIAAgpIADn5QABh9BQg6QBOg6B3AmQAtAOAYAqQAZAqAABEQACCOgBEbIAACqQAABCA4AAQA8ACAAhGIgBl8QABiiCfgaQBngRBHA7QBHA8AABnQABCxgBCyQAAAjAJARQANAXAhACQAeACAPgUQAOgTABgpQAHi6AFg6QACgeAYg3QAthkBfgDQCGgFAnBhQAxB6ACBeQAIIzgIIOQgDDzhlDoQjAG6nUA5QhyAOhwAAQkeAAkThbg");
	this.shape_1.setTransform(-0.0187,0.1794);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.3,-203.3,274.70000000000005,406.6);


(lib._3men = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._3mentalkingphone();
	this.instance.setTransform(-100,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-100,-100,200,200);


(lib.TouchAnimation = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {Tap:0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Touch
	this.instance = new lib.Touch("synched",0);
	this.instance.setTransform(-5.25,-254.7,0.25,0.25,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:-255.65,alpha:0.1094},8).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.6,-285.5,53.3,60.69999999999999);


// stage content:
(lib.TheLearnPhase2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"This is the Learn Phase":15,"In this phase, ":71,"you will become familiar with the entire story ":93,"and retell it in your own language.":155,"It’s helpful to do this with others":208,"First, tap the play button":264,"Listen to the entire story":373,"As you listen, tap again to pause if you need to":567,"Tap here":670,"Tap here":2301,"Translate and revise":2351,"or you can just swipe up":2396,"This is the Learn phase":13,"02 In this phase, you will become familiar with the entire story… and retell it in your own language-":71,"03":208,"04":264,"05":373,"06":567,"07 Listen a few more times":1646,"08 Practice telling":1755,"09 You do not need to tell all the details":1859,"18 after recording the story":2223,"Hindi Jesus told his disciples":2006,"Hindi Fade During the night":2162,"Jesus and the Storm":297,"Jesus told his disciples to sail across the big lake while he prayed by himself.":416,"During the night, a strong wind and storm threatened to capsize the disciples’ boat.":658,"Later in the night, Jesus came to his disciples who were in the boat. He was walking on the water without sinking!":809,"When the disciples saw Jesus, they shouted in fear, “Look! It is a ghost [spirit]!”":993,"Jesus called to them, “Have courage! It is I, Jesus! Don’t be afraid!”":1174,"Immediately, when Jesus got into the boat, the wind and the sea became calm. The disciples were amazed and worshiped him, “You really are the Son of God!”":1341,"Tap animation":289,"Tap animation":611,"Tap animation":647,"Tap animation":2304,"Tap animation":2349,"3 men fade":2172,"Jesus and the storm title slide":0,Jesus:416,"Boat in storm":658,"Jesus walking":808,"They see a ghost":993,"Jesus says don't be afraid":1174,"All is calm":1341};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,13,71,208,264,297,373,416,567,658,809,993,1174,1341,1646,1755,1859,2006,2162,2223];
	this.streamSoundSymbolsList[13] = [{id:"_01ThisistheLearnPhase",startFrame:13,endFrame:71,loop:1,offset:0}];
	this.streamSoundSymbolsList[71] = [{id:"_02Inthisphaseyouwillbecomefamiliarwiththeentirestoryandretellitinyourownlanguage",startFrame:71,endFrame:208,loop:1,offset:0}];
	this.streamSoundSymbolsList[208] = [{id:"_03Itshelpfultodothiswithothers",startFrame:208,endFrame:264,loop:1,offset:0}];
	this.streamSoundSymbolsList[264] = [{id:"_04Firsttaptheplaybutton",startFrame:264,endFrame:373,loop:1,offset:0}];
	this.streamSoundSymbolsList[297] = [{id:"narration0",startFrame:297,endFrame:416,loop:1,offset:0}];
	this.streamSoundSymbolsList[373] = [{id:"_05Listentotheentirestory",startFrame:373,endFrame:567,loop:1,offset:0}];
	this.streamSoundSymbolsList[416] = [{id:"narration1",startFrame:416,endFrame:658,loop:1,offset:0}];
	this.streamSoundSymbolsList[567] = [{id:"_06Asyoulistentapagaintopauseifyouneedto",startFrame:567,endFrame:1646,loop:1,offset:0}];
	this.streamSoundSymbolsList[658] = [{id:"narration2",startFrame:658,endFrame:809,loop:1,offset:0}];
	this.streamSoundSymbolsList[809] = [{id:"narration3",startFrame:809,endFrame:993,loop:1,offset:0}];
	this.streamSoundSymbolsList[993] = [{id:"narration4",startFrame:993,endFrame:1174,loop:1,offset:0}];
	this.streamSoundSymbolsList[1174] = [{id:"narration5",startFrame:1174,endFrame:1341,loop:1,offset:0}];
	this.streamSoundSymbolsList[1341] = [{id:"narration6",startFrame:1341,endFrame:2467,loop:1,offset:0}];
	this.streamSoundSymbolsList[1646] = [{id:"_07Listenafewmoretimesuntilyoucantellthestoryinyourlanguage",startFrame:1646,endFrame:1755,loop:1,offset:0}];
	this.streamSoundSymbolsList[1755] = [{id:"_08Practicetellingtheentirestorytoyourfriendsinyourlanguage",startFrame:1755,endFrame:1859,loop:1,offset:0}];
	this.streamSoundSymbolsList[1859] = [{id:"_09Youdonotneedtotellallthedetailsbuttrytotellagoodsummarythemainpointsofthestory",startFrame:1859,endFrame:2223,loop:1,offset:0}];
	this.streamSoundSymbolsList[2006] = [{id:"Jesustoldhisdisciples_NirajHindiNarrator",startFrame:2006,endFrame:2162,loop:1,offset:0}];
	this.streamSoundSymbolsList[2162] = [{id:"f_Duringthenight_NirajHindiNarrator",startFrame:2162,endFrame:2467,loop:1,offset:0}];
	this.streamSoundSymbolsList[2223] = [{id:"_18AfterrecordingasummaryofthestoryinyourlanguagetapheretogotothenextphaseTranslateandReviseorjustswipeup",startFrame:2223,endFrame:2467,loop:1,offset:0}];
	// timeline functions:
	this.frame_0 = function() {
		this.clearAllSoundStreams();
		 
	}
	this.frame_13 = function() {
		var soundInstance = playSound("_01ThisistheLearnPhase",0);
		this.InsertIntoSoundStreamData(soundInstance,13,71,1);
	}
	this.frame_71 = function() {
		var soundInstance = playSound("_02Inthisphaseyouwillbecomefamiliarwiththeentirestoryandretellitinyourownlanguage",0);
		this.InsertIntoSoundStreamData(soundInstance,71,208,1);
	}
	this.frame_208 = function() {
		var soundInstance = playSound("_03Itshelpfultodothiswithothers",0);
		this.InsertIntoSoundStreamData(soundInstance,208,264,1);
	}
	this.frame_264 = function() {
		var soundInstance = playSound("_04Firsttaptheplaybutton",0);
		this.InsertIntoSoundStreamData(soundInstance,264,373,1);
	}
	this.frame_297 = function() {
		var soundInstance = playSound("narration0",0);
		this.InsertIntoSoundStreamData(soundInstance,297,416,1);
	}
	this.frame_373 = function() {
		var soundInstance = playSound("_05Listentotheentirestory",0);
		this.InsertIntoSoundStreamData(soundInstance,373,567,1);
	}
	this.frame_416 = function() {
		var soundInstance = playSound("narration1",0);
		this.InsertIntoSoundStreamData(soundInstance,416,658,1);
	}
	this.frame_567 = function() {
		var soundInstance = playSound("_06Asyoulistentapagaintopauseifyouneedto",0);
		this.InsertIntoSoundStreamData(soundInstance,567,1646,1);
	}
	this.frame_658 = function() {
		var soundInstance = playSound("narration2",0);
		this.InsertIntoSoundStreamData(soundInstance,658,809,1);
	}
	this.frame_809 = function() {
		var soundInstance = playSound("narration3",0);
		this.InsertIntoSoundStreamData(soundInstance,809,993,1);
	}
	this.frame_993 = function() {
		var soundInstance = playSound("narration4",0);
		this.InsertIntoSoundStreamData(soundInstance,993,1174,1);
	}
	this.frame_1174 = function() {
		var soundInstance = playSound("narration5",0);
		this.InsertIntoSoundStreamData(soundInstance,1174,1341,1);
	}
	this.frame_1341 = function() {
		var soundInstance = playSound("narration6",0);
		this.InsertIntoSoundStreamData(soundInstance,1341,2467,1);
	}
	this.frame_1646 = function() {
		var soundInstance = playSound("_07Listenafewmoretimesuntilyoucantellthestoryinyourlanguage",0);
		this.InsertIntoSoundStreamData(soundInstance,1646,1755,1);
	}
	this.frame_1755 = function() {
		var soundInstance = playSound("_08Practicetellingtheentirestorytoyourfriendsinyourlanguage",0);
		this.InsertIntoSoundStreamData(soundInstance,1755,1859,1);
	}
	this.frame_1859 = function() {
		var soundInstance = playSound("_09Youdonotneedtotellallthedetailsbuttrytotellagoodsummarythemainpointsofthestory",0);
		this.InsertIntoSoundStreamData(soundInstance,1859,2223,1);
	}
	this.frame_2006 = function() {
		var soundInstance = playSound("Jesustoldhisdisciples_NirajHindiNarrator",0);
		this.InsertIntoSoundStreamData(soundInstance,2006,2162,1);
	}
	this.frame_2162 = function() {
		var soundInstance = playSound("f_Duringthenight_NirajHindiNarrator",0);
		this.InsertIntoSoundStreamData(soundInstance,2162,2467,1);
	}
	this.frame_2223 = function() {
		var soundInstance = playSound("_18AfterrecordingasummaryofthestoryinyourlanguagetapheretogotothenextphaseTranslateandReviseorjustswipeup",0);
		this.InsertIntoSoundStreamData(soundInstance,2223,2467,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(13).call(this.frame_13).wait(58).call(this.frame_71).wait(137).call(this.frame_208).wait(56).call(this.frame_264).wait(33).call(this.frame_297).wait(76).call(this.frame_373).wait(43).call(this.frame_416).wait(151).call(this.frame_567).wait(91).call(this.frame_658).wait(151).call(this.frame_809).wait(184).call(this.frame_993).wait(181).call(this.frame_1174).wait(167).call(this.frame_1341).wait(305).call(this.frame_1646).wait(109).call(this.frame_1755).wait(104).call(this.frame_1859).wait(147).call(this.frame_2006).wait(156).call(this.frame_2162).wait(61).call(this.frame_2223).wait(244));

	// Hand
	this.instance = new lib.handbrown("synched",0);
	this.instance.setTransform(312.9,550.2,0.25,0.25,0,0,0,0.2,0.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:155.65,y:123.9},50,cjs.Ease.quadInOut).to({_off:true},7).wait(184).to({_off:false,x:183.15,y:447.65},0).to({x:40.15,y:341.9},32,cjs.Ease.quadInOut).wait(9).to({startPosition:0},0).to({x:182.9,y:468.4},30).wait(252).to({x:183.15,y:447.65},0).to({x:40.15,y:341.9},31,cjs.Ease.quadInOut).wait(10).to({startPosition:0},0).to({x:71.9,y:375.25},12).wait(7).to({startPosition:0},0).to({x:40.15,y:341.9},11).to({x:271.85,y:473.4},23).to({_off:true},1).wait(1560).to({_off:false,x:238.55,y:502.35},0).wait(39).to({startPosition:0},0).to({x:151.15,y:103.4},26).wait(15).to({startPosition:0},0).to({x:170.65,y:142.4},30).wait(16).to({startPosition:0},0).wait(22).to({startPosition:0},0).to({regX:0.3,regY:0.3,rotation:-45,x:165.7,y:462.4},38).to({x:163.85,y:-72.25},28).to({_off:true},2).wait(20));

	// Touch_animation
	this.instance_1 = new lib.TouchAnimation("synched",0,false);
	this.instance_1.setTransform(28.35,274,1,1,0,0,0,-5,-272.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(289).to({_off:false},0).to({_off:true},7).wait(315).to({_off:false,x:27.45,y:281},0).to({_off:true},9).wait(27).to({_off:false},0).to({_off:true},9).wait(1648).to({_off:false,x:137.8,y:42.3},0).to({_off:true},9).wait(36).to({_off:false,x:157.3,y:81.3},0).to({_off:true},9).wait(109));

	// Phase_dropdown_menu
	this.instance_2 = new lib.PhaseDropdown();
	this.instance_2.setTransform(108,41);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2303).to({_off:false},0).to({_off:true},76).wait(88));

	// Slides_together
	this.instance_3 = new lib.Tween9("synched",0);
	this.instance_3.setTransform(538.5,183,0.4854,0.4852,0,0,0,0,0.1);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween10("synched",0);
	this.instance_4.setTransform(-69.5,183.05,0.4854,0.4852,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},72).to({state:[{t:this.instance_4}]},123).to({state:[]},1).wait(2271));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(72).to({_off:false},0).to({_off:true,regY:0.2,x:-69.5,y:183.05},123).wait(2272));

	// _3_men
	this.instance_5 = new lib._3mentalkingphone();
	this.instance_5.setTransform(20,212,1.253,1.253);

	this.instance_6 = new lib.Tween11("synched",0);
	this.instance_6.setTransform(144,319);
	this.instance_6._off = true;

	this.instance_7 = new lib._3men("synched",0);
	this.instance_7.setTransform(144,319);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5,p:{scaleX:1.253,scaleY:1.253,x:20,y:212}}]},209).to({state:[]},44).to({state:[{t:this.instance_5,p:{scaleX:1,scaleY:1,x:44,y:219}}]},1493).to({state:[{t:this.instance_6}]},426).to({state:[{t:this.instance_7}]},31).to({state:[]},214).wait(50));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(2172).to({_off:false},0).to({_off:true,alpha:0},31).wait(264));

	// Rec_Circle2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AjqDpQh0gUg/hfQhIhvBYhgQBJhQBjglQBegjBkgBQBwgIBqAgQB0AjBTBYQAnApg7AKQgUADgPgOQhShKhqgcQhvgfhyAPQhxAOheA8Qh9BRBOBvQAvBCBTAIQBsAHBqgJQBugLBmgqQBkgoBpgPQANgDAFANQAJAYgRAQQhkAxhsAiQhtAjhxANQgyAGgyAAQhGAAhFgLg");
	this.shape.setTransform(130.1638,63.0737);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(17).to({_off:false},0).to({_off:true},105).wait(2345));

	// PhoneFrame
	this.instance_8 = new lib.Tween20("synched",0);
	this.instance_8.setTransform(143,310.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2467));

	// Mask_for_slider (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ArcYPIAAiAMAgLAAAIAACAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:132.7052,y:155.1}).wait(2417).to({graphics:null,x:0,y:0}).wait(50));

	// round_slider_w_line
	this.instance_9 = new lib.slidingball_small();
	this.instance_9.setTransform(-138,299);

	this.instance_10 = new lib.Tween4("synched",0);
	this.instance_10.setTransform(-34.5,303);
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween5("synched",0);
	this.instance_11.setTransform(161.5,303.5);

	var maskedShapeInstanceList = [this.instance_9,this.instance_10,this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).to({state:[{t:this.instance_10}]},288).to({state:[{t:this.instance_10}]},309).to({state:[{t:this.instance_10}]},59).to({state:[{t:this.instance_11}]},987).to({state:[{t:this.instance_10}]},1).to({state:[]},772).to({state:[]},50).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(288).to({_off:false},0).to({x:9.25,y:303.5},309).wait(59).to({x:9.4},0).to({_off:true,x:161.5},987).wait(1).to({_off:false,x:-34.5},0).to({_off:true},772).wait(51));

	// Play_button_mid
	this.instance_12 = new lib.PlayButton();
	this.instance_12.setTransform(22,293);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},328).wait(282).to({_off:false},0).to({_off:true},47).wait(988).to({_off:false},0).to({_off:true},772).wait(50));

	// Pause_button_mid
	this.instance_13 = new lib.pausebutton();
	this.instance_13.setTransform(20,294);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(328).to({_off:false},0).to({_off:true},282).wait(47).to({_off:false},0).to({_off:true},988).wait(822));

	// Play_n_Stop_bottom
	this.instance_14 = new lib.PlayButton();
	this.instance_14.setTransform(201,553);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true},2417).wait(50));

	// Mic_n_Stop
	this.instance_15 = new lib.Microphone();
	this.instance_15.setTransform(83,550);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},2417).wait(50));

	// Mask_for_Swipe_up (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_2418 = new cjs.Graphics().p("EgWdAtiMAAAhUxMAtnAAAMAAABUxg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(2418).to({graphics:mask_1_graphics_2418,x:148.25,y:291.4}).wait(49));

	// Translate_n_Revise_Swipe_up
	this.instance_16 = new lib.TranslateRevisePhase();
	this.instance_16.setTransform(9,574);
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(2418).to({_off:false},0).to({y:42},29).wait(20));

	// LEARN_w_hole
	this.instance_17 = new lib.MainscreenshotwithHoleforimages_Small();
	this.instance_17.setTransform(9,19);

	this.instance_18 = new lib.Tween22("synched",0);
	this.instance_18.setTransform(144,309);
	this.instance_18._off = true;

	this.instance_19 = new lib.Tween23("synched",0);
	this.instance_19.setTransform(144,-220.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17}]}).to({state:[{t:this.instance_18}]},2418).to({state:[{t:this.instance_19}]},29).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(2418).to({_off:false},0).to({_off:true,y:-220.5},29).wait(20));

	// Slides
	this.instance_20 = new lib.Titlepageimage();
	this.instance_20.setTransform(9,82,1.0075,1.0074);

	this.instance_21 = new lib._1();
	this.instance_21.setTransform(9,83,1.0262,1.0254);

	this.instance_22 = new lib._2();
	this.instance_22.setTransform(7,83,1.0076,1.0255);

	this.instance_23 = new lib._3();
	this.instance_23.setTransform(7,73,1.0253,1.0255);

	this.instance_24 = new lib._4();
	this.instance_24.setTransform(7,73,1.0253,1.0255);

	this.instance_25 = new lib._5();
	this.instance_25.setTransform(7,73,1.0259,1.0255);

	this.instance_26 = new lib._6();
	this.instance_26.setTransform(5,73,1.0259,1.0254);

	this.instance_27 = new lib.Tween24("synched",0);
	this.instance_27.setTransform(144,174.75);
	this.instance_27._off = true;

	this.instance_28 = new lib.Tween25("synched",0);
	this.instance_28.setTransform(144,-354.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_20,p:{y:82}}]}).to({state:[{t:this.instance_21}]},416).to({state:[{t:this.instance_22}]},242).to({state:[{t:this.instance_23}]},150).to({state:[{t:this.instance_24}]},185).to({state:[{t:this.instance_25}]},181).to({state:[{t:this.instance_26}]},167).to({state:[{t:this.instance_20,p:{y:83}}]},304).to({state:[{t:this.instance_20,p:{y:83}}]},559).to({state:[{t:this.instance_27}]},214).to({state:[{t:this.instance_28}]},29).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(2418).to({_off:false},0).to({_off:true,y:-354.3},29).wait(20));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-276,-211.5,1164.5,831.9);
// library properties:
lib.properties = {
	id: '84D974CAF933EC42B707E9E41A48798A',
	width: 287,
	height: 618,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/The Learn Phase2_atlas_1.png", id:"The Learn Phase2_atlas_1"},
		{src:"sounds/_01ThisistheLearnPhase.mp3", id:"_01ThisistheLearnPhase"},
		{src:"sounds/_02Inthisphaseyouwillbecomefamiliarwiththeentirestoryandretellitinyourownlanguage.mp3", id:"_02Inthisphaseyouwillbecomefamiliarwiththeentirestoryandretellitinyourownlanguage"},
		{src:"sounds/_03Itshelpfultodothiswithothers.mp3", id:"_03Itshelpfultodothiswithothers"},
		{src:"sounds/_04Firsttaptheplaybutton.mp3", id:"_04Firsttaptheplaybutton"},
		{src:"sounds/_05Listentotheentirestory.mp3", id:"_05Listentotheentirestory"},
		{src:"sounds/_06Asyoulistentapagaintopauseifyouneedto.mp3", id:"_06Asyoulistentapagaintopauseifyouneedto"},
		{src:"sounds/_07Listenafewmoretimesuntilyoucantellthestoryinyourlanguage.mp3", id:"_07Listenafewmoretimesuntilyoucantellthestoryinyourlanguage"},
		{src:"sounds/_08Practicetellingtheentirestorytoyourfriendsinyourlanguage.mp3", id:"_08Practicetellingtheentirestorytoyourfriendsinyourlanguage"},
		{src:"sounds/_09Youdonotneedtotellallthedetailsbuttrytotellagoodsummarythemainpointsofthestory.mp3", id:"_09Youdonotneedtotellallthedetailsbuttrytotellagoodsummarythemainpointsofthestory"},
		{src:"sounds/_18AfterrecordingasummaryofthestoryinyourlanguagetapheretogotothenextphaseTranslateandReviseorjustswipeup.mp3", id:"_18AfterrecordingasummaryofthestoryinyourlanguagetapheretogotothenextphaseTranslateandReviseorjustswipeup"},
		{src:"sounds/f_Duringthenight_NirajHindiNarrator.mp3", id:"f_Duringthenight_NirajHindiNarrator"},
		{src:"sounds/Jesustoldhisdisciples_NirajHindiNarrator.mp3", id:"Jesustoldhisdisciples_NirajHindiNarrator"},
		{src:"sounds/narration0.mp3", id:"narration0"},
		{src:"sounds/narration1.mp3", id:"narration1"},
		{src:"sounds/narration2.mp3", id:"narration2"},
		{src:"sounds/narration3.mp3", id:"narration3"},
		{src:"sounds/narration4.mp3", id:"narration4"},
		{src:"sounds/narration5.mp3", id:"narration5"},
		{src:"sounds/narration6.mp3", id:"narration6"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['84D974CAF933EC42B707E9E41A48798A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;